package com.example.livro

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DetalhesActivity : AppCompatActivity(R.layout.activity_registro) {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Recuperar os TextViews do layout
        val tvTitulo = findViewById<TextView>(R.id.TituloRegistrado)
        val tvAutor = findViewById<TextView>(R.id.AutorRegistrado)

        // Recuperar os dados do Intent
        val titulo = intent.getStringExtra("TITULO") ?: "Sem título"
        val autor = intent.getStringExtra("AUTOR") ?: "Sem autor"

        // Exibir os dados nos TextViews
        tvTitulo.text = "Título: $titulo"
        tvAutor.text = "Autor: $autor"
    }
}