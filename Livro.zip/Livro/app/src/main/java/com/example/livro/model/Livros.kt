package com.example.livro.model

data class Livros(val Titulo : String,
                  val Autor : String)
