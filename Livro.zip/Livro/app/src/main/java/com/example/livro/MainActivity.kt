package com.example.livro

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.livro.model.Livros
import com.google.android.material.floatingactionbutton.FloatingActionButton
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val editTitulo = findViewById<EditText>(R.id.Titulo)
        val editAutor = findViewById<EditText>(R.id.Autor)
        val btnCadastrar = findViewById<Button>(R.id.btnCadastro)
        val fab = findViewById<FloatingActionButton>(R.id.floatingActionButton)

        if (editTitulo == null || editAutor == null || fab == null) {
            Toast.makeText(this, "Erro: Um ou mais views não encontrados", Toast.LENGTH_LONG).show()
            return
        }

        fab.setOnClickListener {
            Toast.makeText(this, "FAB Clicado", Toast.LENGTH_SHORT).show() // Para depuração
            try {
                val Titulo = editTitulo.text.toString().trim()
                val Autor = editAutor.text.toString().trim()

                if (Titulo.isNotEmpty() && Autor.isNotEmpty()) {
                    val livr = Livros(Titulo, Autor)
                    val intent = Intent(this, DetalhesActivity::class.java).apply {
                        putExtra("TITULO", livr.Titulo)
                        putExtra("AUTOR", livr.Autor)
                    }
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        btnCadastrar.setOnClickListener {
            Toast.makeText(this, "Botão Clicado", Toast.LENGTH_SHORT).show()
            try {
                val Titulo = editTitulo.text.toString()
                val Autor = editAutor.text.toString()

                if (Titulo.isNotEmpty() && Autor.isNotEmpty()) {
                    val livr = Livros(Titulo, Autor)
                    val intent = Intent(this, DetalhesActivity::class.java).apply {
                        putExtra("TITULO", livr.Titulo)
                        putExtra("AUTOR", livr.Autor)
                    }
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Erro: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}